<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RainbowVoices - Resources</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
       header {
            background-color: #2c3e50;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            color: white;
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        header img {
            width: 50px;
        }
        header nav {
            display: flex; 
        }
        header nav a {
            text-decoration: none;
            color: #ecf0f1;
            margin: 0 15px;
            font-weight: bold;
        }
        header nav a:hover {
            color: #ff69b4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .container h1 {
            color: white; 
        }
        h1, h2 {
            color: #333;
            margin-bottom: 20px;
        }
        p {
            margin-bottom: 15px;
        }
        .section {
            margin: 40px 0;
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .section-img {
            width: 100%;
            height: auto; 
            object-fit: cover; 
            border-radius: 10px;
        }
        .resource {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            background: #ffffff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .resource-img {
            width: 150px;
            height: auto;
            margin-right: 20px;
            border-radius: 8px;
        }
        .resource-content {
            flex: 1;
        }
        .resource-link {
            display: inline-block;
            margin-top: 10px;
            color: #ff69b4;
            text-decoration: none;
        }
        .resource-link:hover {
            text-decoration: underline;
        }
        .footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: 40px;
            font-size: 0.8em;
        }
        .footer a {
            color: #ff69b4;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <header>
        <img src="images/logo.png" alt="RainbowVoices Logo">
        <nav>
            <a href="http://127.0.0.1:8000/home">Home</a>
            <a href="http://127.0.0.1:8000/content">Resources</a>
            <a href="http://127.0.0.1:8000/about">Stories</a>
        </nav>
    </header>

    <div class="container">
        <section class="section">
            <h1>LGBTQIA+ Resources</h1>

            <h2>Support Groups</h2>
            <p>Find Your Community: Whether you're looking for support online or in person, we've compiled a list of trusted LGBTQIA+ support groups that can help you connect with others.</p>
            <img src="images/group.jpg" alt="LGBTQIA+ Group" class="section-img">

            <div class="resource">
                <img src="images/trevorspace.jpg" alt="TrevorSpace" class="resource-img">
                <div class="resource-content">
                    <h3>TrevorSpace</h3>
                    <p>TrevorSpace is a social networking site for LGBTQIA+ youth, providing a safe and affirming space to connect with others. It offers support and community to those who need it most.</p>
                    <a href="https://www.trevorspace.org" target="_blank" class="resource-link">Visit TrevorSpace</a>
                </div>
            </div>
            <div class="resource">
                <img src="images/pflag.jpg" alt="PFLAG" class="resource-img">
                <div class="resource-content">
                    <h3>PFLAG</h3>
                    <p>PFLAG is a national organization that offers local chapters providing support for LGBTQIA+ individuals and their families. They work to build a supportive network for everyone involved.</p>
                    <a href="https://www.pflag.org" target="_blank" class="resource-link">Visit PFLAG</a>
                </div>
            </div>

            <h2>Educational Resources</h2>
            <p>Education is key to understanding and supporting the LGBTQIA+ community. Here are some books, articles, and websites to help you learn more about LGBTQIA+ history, rights, and culture.</p>
            <img src="images/educ_resource.jpg" class="section-img">

            <div class="resource">
                <img src="images/queer_graphic_history.jpg" alt="Queer: A Graphic History" class="resource-img">
                <div class="resource-content">
                    <h3>Queer: A Graphic History</h3>
                    <p>This book by Meg-John Barker is an illustrated guide to the history of LGBTQIA+. It's a visually engaging way to learn about the past and its impact on the present.</p>
                    <a href="https://www.goodreads.com/book/show/26118155-queer" target="_blank" class="resource-link">Find on Goodreads</a>
                </div>
            </div>
            <div class="resource">
                <img src="images/glaad.jpg" alt="GLAAD" class="resource-img">
                <div class="resource-content">
                    <h3>GLAAD</h3>
                    <p>GLAAD is a leading resource for LGBTQIA+ news, advocacy, and education. Their website provides valuable information on current events and issues affecting the LGBTQIA+ community.</p>
                    <a href="https://www.glaad.org" target="_blank" class="resource-link">Visit GLAAD</a>
                </div>
            </div>

            <h2>Hotlines</h2>
            <p>If you or someone you know is in crisis, please reach out to one of these hotlines. Help is available 24/7.</p>
            <div class="resource">
                <img src="images/trevor_project.jpg" alt="The Trevor Project" class="resource-img">
                <div class="resource-content">
                    <h3>The Trevor Project</h3>
                    <p>The Trevor Project offers crisis intervention and suicide prevention services for LGBTQIA+ youth. They provide support via phone, text, and chat for those in need of immediate help.</p>
                    <a href="https://www.thetrevorproject.org" target="_blank" class="resource-link">Visit The Trevor Project</a>
                </div>
            </div>
            <div class="resource">
                <img src="images/trans_lifeline.jpg" alt="Trans Lifeline" class="resource-img">
                <div class="resource-content">
                    <h3>Trans Lifeline</h3>
                    <p>Trans Lifeline provides peer support services run by and for trans people. They offer crisis support and emotional assistance to the trans community through their hotline.</p>
                    <a href="https://www.translifeline.org" target="_blank" class="resource-link">Visit Trans Lifeline</a>
                </div>
            </div>
        </section>
    </div>

    <footer class="footer">
        <p>&copy; 2024 RainbowVoices. All Rights Reserved. | <a href="home.html">Home</a> | <a href="resources.html">Resources</a> | <a href="stories.html">Stories</a></p>
    </footer>

</body>
</html>